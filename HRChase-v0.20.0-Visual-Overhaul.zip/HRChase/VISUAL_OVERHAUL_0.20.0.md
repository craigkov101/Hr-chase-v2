# HR Chase 0.20.0 — Visual & Navigation Quality Pass

## Scope control
- Based on HRChase 0.19.6. No modifications to MainViewModel, Repository, API parser, Models, scoring engines, preferences or unit tests.
- Data and scoring values in visual components come only from existing typed live candidate/game models (none from image mockup sample values).
- Changed Kotlin UI is `app/src/main/java/com/ckz/hrchase/ui/HrChaseApp.kt`.
- Player summary **does not replace** previous cards; scroll down for full data and analysis.
- A 0–100 HR Chase score is NOT a home run probability. BvP and measured contact samples remain visible.

## Manual Android test checklist
1. Open Games; check today/tomorrow schedule and game cards still list both teams and correct actual MLB start time. Refresh and confirm one game with no lineup still appears.
2. Open a game's `View all` section: see all available ranked batters for both teams. Tap a name to open detail; Android back gesture/button returns to the expanded game. Android back again collapses the game.
3. Profile: BvP values load or gracefully show no verified sample. Pitch Arsenal Fits shows real pitch names and usage, or says unavailable. Recent Contact shows real EV, LA, barrel, hard hit, pull, sweet spot; check old detailed contact log and research remain below.
4. Profile: Track Pick toggles the tracked state; navigating to Tracked and pressing Back returns to previous tab.
5. Game: Build HR Parlay routes to existing generator. Android back returns to Games. Try 1–5 legs, including filters and round-robin options.
6. More -> Hot/Heating/AAA/Pitcher Ks -> Back returns to More. AAA profile back returns to AAA.
7. Test Android physical/gesture Back on phone, portrait orientation, notification/status bars, large font, 360dp width, pull-to-refresh, no data, slow data, airplane mode.
8. Run all Gradle unit tests (`gradle testDebugUnitTest`) and build (`gradle assembleDebug`) with installed Android SDK.

## GitHub Actions
Upload/extract this zip into repository **root**, including `.github/workflows/android-build.yml`. In GitHub Actions run **HR Chase v0.20.0 Android APK** -> **Run workflow**. Artifacts include the debug APK. No user credentials, account or paid API keys were added.
